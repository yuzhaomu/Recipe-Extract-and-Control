"""
菜谱关系抽取训练数据生成脚本 v2
改进：更合理的单位匹配、更自然的中文表达、更多样化的模板
"""

import json
import random
import os
import re

random.seed(42)

# ============ 词汇资源库（更细致的分类）============

# 小食材（适合用 个/粒/瓣/条 计数）
SMALL_INGREDIENTS = [
    "大蒜", "生姜", "小葱", "香菜", "韭菜", "小米椒", "干辣椒", "花椒", "八角",
    "鸡蛋", "鹌鹑蛋", "虾仁", "蛤蜊", "扇贝", "鸡翅", "鸡爪", "猪蹄", "排骨",
    "玉米", "茄子", "黄瓜", "胡萝卜", "莲藕", "山药", "南瓜", "洋葱", "青椒", "红椒",
    "西红柿", "土豆", "芹菜", "菠菜", "生菜", "白菜", "西兰花", "花菜", "豆角",
    "香菇", "金针菇", "平菇", "木耳", "豆腐", "腐竹", "年糕", "馒头",
]

# 大食材（适合用 克/千克/斤 称重）
LARGE_INGREDIENTS = [
    "猪肉", "牛肉", "羊肉", "鸡胸肉", "鸡腿", "鸭肉", "五花肉", "里脊肉",
    "牛腩", "羊排", "肥肠", "猪肝", "猪肚", "牛筋", "火腿", "培根", "香肠",
    "鲫鱼", "鲈鱼", "草鱼", "带鱼", "三文鱼", "鱿鱼", "章鱼", "螃蟹", "小龙虾",
    "土豆", "冬瓜", "南瓜", "红薯", "芋头", "山药", "莲藕",
]

# 全部食材（去重）
ALL_INGREDIENTS = list(dict.fromkeys(SMALL_INGREDIENTS + LARGE_INGREDIENTS))

SEASONINGS = [
    "盐", "白糖", "冰糖", "生抽", "老抽", "蚝油", "料酒", "陈醋", "白醋",
    "番茄酱", "豆瓣酱", "辣椒酱", "花椒", "八角", "桂皮", "香叶",
    "孜然", "胡椒粉", "淀粉", "食用油", "芝麻油", "辣椒粉", "孜然粉",
    "五香粉", "鸡精", "味精", "蜂蜜",
]

# 食材 → 推荐单位（权重）
INGREDIENT_UNIT_WEIGHTS = {
    # 计数类
    "大蒜": {"瓣": 0.6, "个": 0.2, "适量": 0.1, "克": 0.1},
    "生姜": {"片": 0.4, "克": 0.3, "块": 0.2, "适量": 0.1},
    "小葱": {"根": 0.5, "把": 0.3, "适量": 0.2},
    "鸡蛋": {"个": 0.8, "适量": 0.1, "克": 0.1},
    "鸡翅": {"个": 0.7, "只": 0.2, "适量": 0.1},
    "鸡爪": {"个": 0.6, "只": 0.3, "适量": 0.1},
    "排骨": {"克": 0.5, "斤": 0.3, "块": 0.1, "适量": 0.1},
    "玉米": {"根": 0.6, "个": 0.3, "适量": 0.1},
    # 默认
    "__default__": {"克": 0.4, "个": 0.2, "适量": 0.15, "斤": 0.1, "千克": 0.05, "片": 0.05, "块": 0.05},
}

# 食材 → 推荐份量范围
INGREDIENT_AMOUNT_RANGE = {
    "大蒜": (1, 5),
    "生姜": (1, 3),
    "小葱": (1, 3),
    "鸡蛋": (1, 5),
    "鸡翅": (4, 10),
    "鸡爪": (5, 12),
    "虾仁": (50, 200),
    "猪肉": (100, 500),
    "牛肉": (100, 500),
    "土豆": (100, 500),
    "西红柿": (1, 3),
    "青椒": (1, 3),
    "__default__": (50, 500),
}

# 调料 → 推荐单位
SEASONING_UNIT_WEIGHTS = {
    "盐": {"适量": 0.5, "克": 0.3, "勺": 0.15, "茶匙": 0.05},
    "白糖": {"勺": 0.4, "适量": 0.3, "克": 0.2, "茶匙": 0.1},
    "生抽": {"勺": 0.5, "适量": 0.2, "毫升": 0.2, "汤匙": 0.1},
    "老抽": {"勺": 0.5, "适量": 0.2, "毫升": 0.2, "汤匙": 0.1},
    "料酒": {"勺": 0.4, "适量": 0.2, "毫升": 0.3, "汤匙": 0.1},
    "醋": {"勺": 0.4, "适量": 0.2, "毫升": 0.3, "汤匙": 0.1},
    "蚝油": {"勺": 0.5, "适量": 0.3, "毫升": 0.15, "汤匙": 0.05},
    "淀粉": {"勺": 0.4, "适量": 0.3, "克": 0.2, "茶匙": 0.1},
    "食用油": {"勺": 0.4, "适量": 0.2, "毫升": 0.3, "汤匙": 0.1},
    "__default__": {"适量": 0.4, "勺": 0.3, "克": 0.15, "茶匙": 0.1, "毫升": 0.05},
}

PREPARATIONS = {
    "切": ["切丝", "切片", "切块", "切丁", "切碎", "切末", "剁碎"],
    "处理": ["去皮", "去籽", "去蒂", "洗净", "沥干", "擦干", "掰开", "撕开", "拍碎", "压扁", "剥皮"],
    "腌泡": ["腌制", "浸泡", "焯水", "过油", "炸至金黄", "煎至两面金黄"],
    "混合": ["搅拌均匀", "打散", "混合", "揉成面团", "捏成丸子", "抓匀"],
}

ACTIONS = {
    "炒": ["翻炒", "煸炒", "爆香", "干煸", "炒"],
    "煮": ["煮", "炖", "煲", "熬", "焯水"],
    "蒸": ["蒸", "隔水蒸"],
    "炸": ["炸", "煎", "烤", "烘"],
    "拌": ["拌匀", "搅拌", "抓匀", "腌制"],
    "通用": ["放入", "加入", "倒入", "撒入", "淋入", "裹上", "码入", "摆盘", "烧热"],
}

COOKING_TIMES = [
    "1分钟", "2分钟", "3分钟", "5分钟", "8分钟", "10分钟", "15分钟",
    "20分钟", "25分钟", "30分钟", "40分钟", "1小时", "1.5小时", "2小时",
    "半小时", "十几分钟", "几分钟", "45分钟", "50分钟",
]

# ============ 工具函数 ============

entity_id_counter = 0

def get_id():
    global entity_id_counter
    entity_id_counter += 1
    return entity_id_counter

def reset_id():
    global entity_id_counter
    entity_id_counter = 0

def pick(items):
    return random.choice(items)

def pick_n(items, n):
    return random.sample(items, min(n, len(items)))

def weighted_choice(weights_dict):
    """按权重随机选择一个key"""
    items = list(weights_dict.keys())
    weights = list(weights_dict.values())
    return random.choices(items, weights=weights, k=1)[0]

def generate_amount_ingredient(ingredient):
    """为食材生成合理的份量"""
    # 选单位
    unit_weights = INGREDIENT_UNIT_WEIGHTS.get(ingredient, INGREDIENT_UNIT_WEIGHTS["__default__"])
    unit = weighted_choice(unit_weights)
    
    if unit in ["适量", "少许", "少量"]:
        return unit
    
    # 选数值
    low, high = INGREDIENT_AMOUNT_RANGE.get(ingredient, INGREDIENT_AMOUNT_RANGE["__default__"])
    num = random.randint(low, high)
    
    # 对大数用更友好的表达
    if unit == "克" and num >= 500:
        # 50% 概率转为千克或斤
        if random.random() < 0.5:
            unit = "千克"
            num = round(num / 1000, 1)
        else:
            unit = "斤"
            num = round(num / 500, 1)
    
    # 整数不显示 .0
    if isinstance(num, float) and num.is_integer():
        num = int(num)
    
    return f"{num}{unit}"

def generate_amount_seasoning(seasoning):
    """为调料生成合理的份量"""
    unit_weights = SEASONING_UNIT_WEIGHTS.get(seasoning, SEASONING_UNIT_WEIGHTS["__default__"])
    unit = weighted_choice(unit_weights)
    
    if unit == "适量":
        return unit
    
    if unit in ["勺", "汤匙"]:
        num = random.choice([1, 1, 1, 2, 2, 3, 0.5])
    elif unit == "茶匙":
        num = random.choice([0.5, 1, 1, 2])
    elif unit == "毫升":
        num = random.choice([5, 10, 15, 20, 30, 50])
    elif unit == "克":
        num = random.choice([1, 2, 3, 5, 10, 15, 20])
    else:
        num = 1
    
    if isinstance(num, float) and num.is_integer():
        num = int(num)
    
    return f"{num}{unit}"


# ============ 模板定义 ============

def template_simple_ingredients():
    """
    模板1: 简单食材列举
    例: 土豆300克切丝，青椒1个去籽切块
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    n = random.randint(2, 4)
    selected = pick_n(ALL_INGREDIENTS, n)
    
    for i, ing in enumerate(selected):
        eid = get_id()
        amount = generate_amount_ingredient(ing)
        prep = pick(pick([PREPARATIONS["切"], PREPARATIONS["处理"]]))
        
        if i < n - 1:
            seg = f"{ing}{amount}{prep}，"
        else:
            seg = f"{ing}{amount}{prep}"
        
        start = sum(len(p) for p in parts)
        parts.append(seg)
        
        # 食材
        entities.append({"id": eid, "start": start, "end": start + len(ing), "label": "食材"})
        
        # 份量
        eid_a = get_id()
        a_start = start + len(ing)
        a_end = a_start + len(amount)
        entities.append({"id": eid_a, "start": a_start, "end": a_end, "label": "份量"})
        relations.append({"from": eid, "to": eid_a, "type": "食材-份量"})
        
        # 处理方式
        eid_p = get_id()
        p_start = a_end
        p_end = p_start + len(prep)
        entities.append({"id": eid_p, "start": p_start, "end": p_end, "label": "处理方式"})
        relations.append({"from": eid, "to": eid_p, "type": "食材-处理方式"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_seasonings():
    """
    模板2: 调料列举
    例: 加入生抽1勺、老抽半勺、盐适量调味
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    n = random.randint(2, 4)
    selected = pick_n(SEASONINGS, n)
    
    # 生成调料+份量对
    sea_pairs = []
    for sea in selected:
        amt = generate_amount_seasoning(sea)
        sea_pairs.append((sea, amt))
    
    # 拼文本
    if n == 2:
        seg = f"加入{selected[0]}{sea_pairs[0][1]}和{selected[1]}{sea_pairs[1][1]}调味"
    else:
        middle = "、".join(f"{s}{a}" for s, a in sea_pairs[:-1])
        seg = f"加入{middle}和{sea_pairs[-1][0]}{sea_pairs[-1][1]}调味"
    
    parts.append(seg)
    
    # 解析位置
    full_text = seg
    # 找到"加入"后的内容
    after_加入 = full_text[len("加入"):]
    # 去掉"调味"
    content = after_加入[:after_加入.index("调味")] if "调味" in after_加入 else after_加入
    
    # 逐个定位调料
    search_start = len("加入")
    for i, (sea, amt) in enumerate(sea_pairs):
        sea_pos = full_text.index(sea, search_start)
        sea_abs_start = sea_pos
        sea_abs_end = sea_pos + len(sea)
        
        eid_s = get_id()
        entities.append({"id": eid_s, "start": sea_abs_start, "end": sea_abs_end, "label": "调料"})
        
        # 份量紧跟调料后
        amt_pos = sea_abs_end
        amt_abs_end = amt_pos + len(amt)
        
        eid_a = get_id()
        entities.append({"id": eid_a, "start": amt_pos, "end": amt_abs_end, "label": "份量"})
        relations.append({"from": eid_s, "to": eid_a, "type": "调料-份量"})
        
        search_start = amt_abs_end
    
    text = full_text + "。"
    return text, entities, relations


def template_cooking_step():
    """
    模板3: 完整烹饪步骤
    例: 热锅下油，放入土豆丝翻炒5分钟，加入盐调味
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 前缀
    prefix = pick([
        "热锅下油，", "锅中倒油烧热，", "平底锅加热，", "锅中放油，",
        "起锅烧油，", "锅烧热后倒油，"
    ])
    parts.append(prefix)
    
    # 动作 + 食材
    action = pick(ACTIONS["炒"] + ACTIONS["通用"][:3])
    ing = pick(ALL_INGREDIENTS)
    prep = pick(pick([PREPARATIONS["切"], PREPARATIONS["处理"]]))
    
    seg_mid = f"{action}{ing}{prep}"
    parts.append(seg_mid)
    
    # 动作实体
    eid_act = get_id()
    act_start = len(prefix)
    act_end = act_start + len(action)
    entities.append({"id": eid_act, "start": act_start, "end": act_end, "label": "动作"})
    
    # 食材实体
    eid_ing = get_id()
    ing_start = act_end
    ing_end = ing_start + len(ing)
    entities.append({"id": eid_ing, "start": ing_start, "end": ing_end, "label": "食材"})
    relations.append({"from": eid_act, "to": eid_ing, "type": "动作-对象"})
    
    # 处理方式
    eid_prep = get_id()
    prep_start = ing_end
    prep_end = prep_start + len(prep)
    entities.append({"id": eid_prep, "start": prep_start, "end": prep_end, "label": "处理方式"})
    relations.append({"from": eid_ing, "to": eid_prep, "type": "食材-处理方式"})
    
    # 时间
    cook_time = pick(COOKING_TIMES)
    seg_time = f"{cook_time}"
    parts.append(seg_time)
    
    eid_time = get_id()
    time_start = len(prefix) + len(seg_mid)
    time_end = time_start + len(cook_time)
    entities.append({"id": eid_time, "start": time_start, "end": time_end, "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    
    # 调料后缀
    sea = pick(SEASONINGS)
    sea_amt = generate_amount_seasoning(sea)
    seg_sea = f"，加入{sea}{sea_amt}调味"
    parts.append(seg_sea)
    
    eid_sea = get_id()
    # seg_sea = f"，加入{sea}{sea_amt}调味"
    # 调料名在 "加入" 之后
    sea_start = sum(len(p) for p in parts[:-1]) + 3  # "，" + "加" + "入" = 3 chars before sea
    sea_end = sea_start + len(sea)
    entities.append({"id": eid_sea, "start": sea_start, "end": sea_end, "label": "调料"})
    
    eid_sa = get_id()
    sa_start = sea_end
    sa_end = sa_start + len(sea_amt)
    entities.append({"id": eid_sa, "start": sa_start, "end": sa_end, "label": "份量"})
    relations.append({"from": eid_sea, "to": eid_sa, "type": "调料-份量"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_marinade():
    """
    模板4: 腌制/预处理
    例: 将鸡腿500克用生抽2勺、料酒1勺腌制20分钟
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    ing = pick(LARGE_INGREDIENTS)
    amt = generate_amount_ingredient(ing)
    
    seg1 = f"将{ing}{amt}"
    parts.append(seg1)
    
    # 食材
    eid_ing = get_id()
    entities.append({"id": eid_ing, "start": 1, "end": 1 + len(ing), "label": "食材"})
    
    # 份量
    eid_a = get_id()
    a_start = 1 + len(ing)
    a_end = a_start + len(amt)
    entities.append({"id": eid_a, "start": a_start, "end": a_end, "label": "份量"})
    relations.append({"from": eid_ing, "to": eid_a, "type": "食材-份量"})
    
    # 调料
    n_sea = random.randint(1, 3)
    selected_sea = pick_n(SEASONINGS, n_sea)
    sea_pairs = []
    for s in selected_sea:
        sea_pairs.append((s, generate_amount_seasoning(s)))
    
    sea_text = "、".join(f"{s}{a}" for s, a in sea_pairs)
    
    cook_time = pick(COOKING_TIMES)
    
    # 腌制/浸泡/抓匀
    verb = pick(["腌制", "腌制", "腌制", "浸泡", "抓匀腌制"])
    seg2 = f"用{sea_text}{verb}{cook_time}"
    parts.append(seg2)
    
    # 动作
    verb_pos = seg2.index(verb)
    eid_act = get_id()
    act_start = len(seg1) + verb_pos
    act_end = act_start + len(verb)
    entities.append({"id": eid_act, "start": act_start, "end": act_end, "label": "动作"})
    relations.append({"from": eid_act, "to": eid_ing, "type": "动作-对象"})
    
    # 时间
    eid_time = get_id()
    time_start = act_end
    time_end = time_start + len(cook_time)
    entities.append({"id": eid_time, "start": time_start, "end": time_end, "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    
    # 调料及份量
    search_start = len("用")
    for s, a in sea_pairs:
        s_pos = seg2.index(s, search_start)
        eid_s = get_id()
        entities.append({"id": eid_s, "start": len(seg1) + s_pos, "end": len(seg1) + s_pos + len(s), "label": "调料"})
        
        a_pos = s_pos + len(s)
        eid_a2 = get_id()
        entities.append({"id": eid_a2, "start": len(seg1) + a_pos, "end": len(seg1) + a_pos + len(a), "label": "份量"})
        relations.append({"from": eid_s, "to": eid_a2, "type": "调料-份量"})
        
        search_start = a_pos + len(a)
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_multi_step():
    """
    模板5: 多步骤连贯
    例: 土豆300克去皮切丝，青椒1个去籽切块，热锅爆香蒜末，下入土豆丝翻炒3分钟
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 食材1
    ing1 = pick(ALL_INGREDIENTS)
    amt1 = generate_amount_ingredient(ing1)
    prep1 = pick(pick([PREPARATIONS["切"], PREPARATIONS["处理"]]))
    
    seg1 = f"{ing1}{amt1}{prep1}，"
    parts.append(seg1)
    
    eid1 = get_id()
    entities.append({"id": eid1, "start": 0, "end": len(ing1), "label": "食材"})
    
    eid1a = get_id()
    entities.append({"id": eid1a, "start": len(ing1), "end": len(ing1) + len(amt1), "label": "份量"})
    relations.append({"from": eid1, "to": eid1a, "type": "食材-份量"})
    
    eid1p = get_id()
    entities.append({"id": eid1p, "start": len(ing1) + len(amt1), "end": len(ing1) + len(amt1) + len(prep1), "label": "处理方式"})
    relations.append({"from": eid1, "to": eid1p, "type": "食材-处理方式"})
    
    # 食材2
    ing2 = pick(ALL_INGREDIENTS)
    while ing2 == ing1:
        ing2 = pick(ALL_INGREDIENTS)
    amt2 = generate_amount_ingredient(ing2)
    prep2 = pick(pick([PREPARATIONS["切"], PREPARATIONS["处理"]]))
    
    seg2 = f"{ing2}{amt2}{prep2}，"
    parts.append(seg2)
    
    offset2 = len(seg1)
    eid2 = get_id()
    entities.append({"id": eid2, "start": offset2, "end": offset2 + len(ing2), "label": "食材"})
    
    eid2a = get_id()
    entities.append({"id": eid2a, "start": offset2 + len(ing2), "end": offset2 + len(ing2) + len(amt2), "label": "份量"})
    relations.append({"from": eid2, "to": eid2a, "type": "食材-份量"})
    
    eid2p = get_id()
    entities.append({"id": eid2p, "start": offset2 + len(ing2) + len(amt2), "end": offset2 + len(ing2) + len(amt2) + len(prep2), "label": "处理方式"})
    relations.append({"from": eid2, "to": eid2p, "type": "食材-处理方式"})
    
    # 动作句
    prefix_action = pick(["热锅", "起锅", "锅中"])
    action = pick(ACTIONS["炒"] + ["爆香", "下入", "放入"])
    
    # 选动作作用的食材
    target_ing = pick([ing1, ing2])
    target_eid = eid1 if target_ing == ing1 else eid2
    
    cook_time = pick(COOKING_TIMES)
    
    seg3 = f"{prefix_action}{action}{target_ing}{cook_time}"
    parts.append(seg3)
    
    offset3 = len(seg1) + len(seg2)
    
    # 找动作位置
    act_in_seg = seg3.index(action)
    eid_act = get_id()
    entities.append({"id": eid_act, "start": offset3 + act_in_seg, "end": offset3 + act_in_seg + len(action), "label": "动作"})
    relations.append({"from": eid_act, "to": target_eid, "type": "动作-对象"})
    
    # 时间
    time_in_seg = seg3.index(cook_time)
    eid_time = get_id()
    entities.append({"id": eid_time, "start": offset3 + time_in_seg, "end": offset3 + time_in_seg + len(cook_time), "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_stir_fry_full():
    """
    模板6: 完整炒菜流程
    例: 锅中倒油烧热，下入葱姜蒜爆香，加入牛肉翻炒至变色，放生抽1勺、盐适量调味
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 前缀
    seg1 = "锅中倒油烧热，"
    parts.append(seg1)
    
    # 爆香
    aromatics = pick_n(["葱", "姜", "蒜", "洋葱"], random.randint(2, 3))
    aromatics_text = "、".join(aromatics)
    
    seg2 = f"下入{aromatics_text}爆香，"
    parts.append(seg2)
    
    # 爆香动作
    offset2 = len(seg1)
    act_pos = seg2.index("爆香")
    eid_act1 = get_id()
    entities.append({"id": eid_act1, "start": offset2 + act_pos, "end": offset2 + act_pos + 2, "label": "动作"})
    
    for a in aromatics:
        a_pos = seg2.index(a)
        eid_a = get_id()
        entities.append({"id": eid_a, "start": offset2 + a_pos, "end": offset2 + a_pos + len(a), "label": "食材"})
        relations.append({"from": eid_act1, "to": eid_a, "type": "动作-对象"})
    
    # 主料
    main_ing = pick(ALL_INGREDIENTS)
    amt = generate_amount_ingredient(main_ing)
    action2 = pick(ACTIONS["炒"])
    cook_time = pick(COOKING_TIMES)
    
    seg3 = f"加入{main_ing}{amt}{action2}{cook_time}"
    parts.append(seg3)
    
    offset3 = len(seg1) + len(seg2)
    
    # 动作2
    act2_pos = seg3.index(action2)
    eid_act2 = get_id()
    entities.append({"id": eid_act2, "start": offset3 + act2_pos, "end": offset3 + act2_pos + len(action2), "label": "动作"})
    
    # 主料
    main_pos = seg3.index(main_ing)
    eid_main = get_id()
    entities.append({"id": eid_main, "start": offset3 + main_pos, "end": offset3 + main_pos + len(main_ing), "label": "食材"})
    relations.append({"from": eid_act2, "to": eid_main, "type": "动作-对象"})
    
    # 主料份量
    amt_pos = main_pos + len(main_ing)
    eid_ma = get_id()
    entities.append({"id": eid_ma, "start": offset3 + amt_pos, "end": offset3 + amt_pos + len(amt), "label": "份量"})
    relations.append({"from": eid_main, "to": eid_ma, "type": "食材-份量"})
    
    # 时间
    time_pos = seg3.index(cook_time)
    eid_time = get_id()
    entities.append({"id": eid_time, "start": offset3 + time_pos, "end": offset3 + time_pos + len(cook_time), "label": "时间"})
    relations.append({"from": eid_act2, "to": eid_time, "type": "动作-时间"})
    
    # 调料后缀
    n_sea = random.randint(1, 3)
    selected_sea = pick_n(SEASONINGS, n_sea)
    
    sea_pairs = []
    for s in selected_sea:
        sa = generate_amount_seasoning(s)
        sea_pairs.append((s, sa))
    
    if len(sea_pairs) == 1:
        seg4 = f"，放{sea_pairs[0][0]}{sea_pairs[0][1]}调味"
    else:
        seg4 = f"，放{'、'.join(f'{s}{a}' for s, a in sea_pairs)}调味"
    parts.append(seg4)
    
    offset4 = len(seg1) + len(seg2) + len(seg3)
    search_pos = 2  # 跳过 "，放"
    for s, sa in sea_pairs:
        # 在seg4中定位调料
        s_pos = seg4.index(s, search_pos)
        eid_s = get_id()
        entities.append({"id": eid_s, "start": offset4 + s_pos, "end": offset4 + s_pos + len(s), "label": "调料"})
        
        # 份量紧跟调料后
        a_pos = s_pos + len(s)
        eid_sa = get_id()
        entities.append({"id": eid_sa, "start": offset4 + a_pos, "end": offset4 + a_pos + len(sa), "label": "份量"})
        relations.append({"from": eid_s, "to": eid_sa, "type": "调料-份量"})
        
        search_pos = a_pos + len(sa)
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_boiled_stew():
    """
    模板7: 煮/炖菜
    例: 锅中加入1000毫升清水，放入排骨500克，大火烧开后转小火炖40分钟
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    seg1 = pick([
        "锅中加入清水，", "汤锅中放入清水，", "锅中倒水，"
    ])
    parts.append(seg1)
    
    # 水/汤
    liquid_amt = f"{random.choice([500, 800, 1000, 1500, 2000])}毫升"
    seg2 = f"加入{liquid_amt}，"
    parts.append(seg2)
    
    # 液体实体
    liquid_pos = seg2.index(liquid_amt)
    eid_liq = get_id()
    entities.append({"id": eid_liq, "start": len(seg1) + liquid_pos, "end": len(seg1) + liquid_pos + len(liquid_amt), "label": "份量"})
    
    # 主料
    main_ing = pick(LARGE_INGREDIENTS)
    amt = generate_amount_ingredient(main_ing)
    
    # 动作
    action_verb = pick(["放入", "下入", "加入"])
    seg3 = f"{action_verb}{main_ing}{amt}，"
    parts.append(seg3)
    
    offset3 = len(seg1) + len(seg2)
    
    eid_act = get_id()
    act_start = offset3
    act_end = act_start + len(action_verb)
    entities.append({"id": eid_act, "start": act_start, "end": act_end, "label": "动作"})
    
    eid_ing = get_id()
    ing_start = act_end
    ing_end = ing_start + len(main_ing)
    entities.append({"id": eid_ing, "start": ing_start, "end": ing_end, "label": "食材"})
    relations.append({"from": eid_act, "to": eid_ing, "type": "动作-对象"})
    
    eid_ia = get_id()
    ia_start = ing_end
    ia_end = ia_start + len(amt)
    entities.append({"id": eid_ia, "start": ia_start, "end": ia_end, "label": "份量"})
    relations.append({"from": eid_ing, "to": eid_ia, "type": "食材-份量"})
    
    # 时间描述
    fire_desc = pick([
        "大火烧开后转小火炖", "大火煮开后转中小火炖", "大火烧开后转小火煲"
    ])
    cook_time = pick(["30分钟", "40分钟", "1小时", "1.5小时", "2小时"])
    
    seg4 = f"{fire_desc}{cook_time}"
    parts.append(seg4)
    
    offset4 = len(seg1) + len(seg2) + len(seg3)
    time_pos = seg4.index(cook_time)
    eid_time = get_id()
    entities.append({"id": eid_time, "start": offset4 + time_pos, "end": offset4 + time_pos + len(cook_time), "label": "时间"})
    # 这里动作是隐含的（炖/煲），简化处理：不额外标动作实体
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_list_with_prep():
    """
    模板8: 食材准备清单
    例: 食材：土豆200克（切丝）、牛肉150克（切片）、青椒1个（去籽）
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    seg0 = "食材："
    parts.append(seg0)
    
    n = random.randint(3, 5)
    selected = pick_n(ALL_INGREDIENTS, n)
    
    for i, ing in enumerate(selected):
        amt = generate_amount_ingredient(ing)
        prep = pick(pick([PREPARATIONS["切"], PREPARATIONS["处理"]]))
        
        if i < n - 1:
            seg = f"{ing}{amt}（{prep}）、"
        else:
            seg = f"{ing}{amt}（{prep}）"
        parts.append(seg)
        
        offset = sum(len(p) for p in parts[:-1])
        
        # 食材
        eid = get_id()
        entities.append({"id": eid, "start": offset, "end": offset + len(ing), "label": "食材"})
        
        # 份量
        eid_a = get_id()
        a_start = offset + len(ing)
        a_end = a_start + len(amt)
        entities.append({"id": eid_a, "start": a_start, "end": a_end, "label": "份量"})
        relations.append({"from": eid, "to": eid_a, "type": "食材-份量"})
        
        # 处理方式（在括号中）
        eid_p = get_id()
        p_start = a_end + 1  # 跳过"（"
        p_end = p_start + len(prep)
        entities.append({"id": eid_p, "start": p_start, "end": p_end, "label": "处理方式"})
        relations.append({"from": eid, "to": eid_p, "type": "食材-处理方式"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_seasoning_mix():
    """
    模板9: 调料混合
    例: 碗中加入生抽2勺、老抽1勺、白糖半勺、淀粉1勺，搅拌均匀
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    seg0 = pick(["碗中加入", "调料碗中放入", "小碗里加入"])
    parts.append(seg0)
    
    n = random.randint(3, 5)
    selected = pick_n(SEASONINGS, n)
    
    sea_pairs = []
    for s in selected:
        sea_pairs.append((s, generate_amount_seasoning(s)))
    
    middle = "、".join(f"{s}{a}" for s, a in sea_pairs)
    
    mix_action = pick(["搅拌均匀", "调匀", "拌匀", "混合均匀"])
    seg1 = f"{middle}，{mix_action}"
    parts.append(seg1)
    
    # 动作
    offset1 = len(seg0)
    act_pos = seg1.rfind(mix_action)
    eid_act = get_id()
    entities.append({"id": eid_act, "start": offset1 + act_pos, "end": offset1 + act_pos + len(mix_action), "label": "动作"})
    
    # 调料
    search_start = len(seg0)
    for s, a in sea_pairs:
        s_pos = seg1.index(s, search_start - len(seg0))
        eid_s = get_id()
        entities.append({"id": eid_s, "start": len(seg0) + s_pos, "end": len(seg0) + s_pos + len(s), "label": "调料"})
        
        a_pos = s_pos + len(s)
        eid_a = get_id()
        entities.append({"id": eid_a, "start": len(seg0) + a_pos, "end": len(seg0) + a_pos + len(a), "label": "份量"})
        relations.append({"from": eid_s, "to": eid_a, "type": "调料-份量"})
        
        search_start = len(seg0) + a_pos + len(a)
    
    text = "".join(parts) + "。"
    return text, entities, relations


def template_steam_bake():
    """
    模板10: 蒸/烤类
    例: 将鲈鱼1条腌制后放入蒸锅，大火蒸15分钟，出锅淋生抽2勺
    """
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 食材
    fish_or_meat = pick(["鲈鱼", "鲫鱼", "草鱼", "鸡胸肉", "排骨", "五花肉"])
    amt = generate_amount_ingredient(fish_or_meat)
    
    seg1 = f"将{fish_or_meat}{amt}"
    parts.append(seg1)
    
    eid_ing = get_id()
    entities.append({"id": eid_ing, "start": 1, "end": 1 + len(fish_or_meat), "label": "食材"})
    
    eid_a = get_id()
    a_start = 1 + len(fish_or_meat)
    a_end = a_start + len(amt)
    entities.append({"id": eid_a, "start": a_start, "end": a_end, "label": "份量"})
    relations.append({"from": eid_ing, "to": eid_a, "type": "食材-份量"})
    
    # 腌制
    seg2 = "腌制20分钟，"
    parts.append(seg2)
    # 不单独标腌制动作（简化）
    
    # 蒸/烤
    cook_method = pick(["放入蒸锅，大火蒸", "送入烤箱，200度烤", "放入蒸笼，中火蒸"])
    cook_time = pick(COOKING_TIMES)
    
    seg3 = f"{cook_method}{cook_time}"
    parts.append(seg3)
    
    offset3 = len(seg1) + len(seg2)
    # 找动作
    if "蒸" in cook_method:
        act_name = "蒸"
    elif "烤" in cook_method:
        act_name = "烤"
    else:
        act_name = "蒸"
    
    act_pos = seg3.index(act_name) if act_name in seg3 else 0
    eid_act = get_id()
    entities.append({"id": eid_act, "start": offset3 + act_pos, "end": offset3 + act_pos + len(act_name), "label": "动作"})
    relations.append({"from": eid_act, "to": eid_ing, "type": "动作-对象"})
    
    # 时间
    time_pos = seg3.index(cook_time)
    eid_time = get_id()
    entities.append({"id": eid_time, "start": offset3 + time_pos, "end": offset3 + time_pos + len(cook_time), "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    
    # 出锅加调料
    sea = pick(["生抽", "蒸鱼豉油", "香油"])
    sea_amt = generate_amount_seasoning(sea)
    seg4 = f"，出锅淋{sea}{sea_amt}"
    parts.append(seg4)
    
    offset4 = offset3 + len(seg3)
    eid_sea = get_id()
    # seg4 = f"，出锅淋{sea}{sea_amt}" → "，" + "出锅" + "淋" = 4 chars before sea
    sea_start = offset4 + 4  # skip "，出锅淋"
    sea_end = sea_start + len(sea)
    entities.append({"id": eid_sea, "start": sea_start, "end": sea_end, "label": "调料"})
    
    eid_sa = get_id()
    sa_start = sea_end
    sa_end = sa_start + len(sea_amt)
    entities.append({"id": eid_sa, "start": sa_start, "end": sa_end, "label": "份量"})
    relations.append({"from": eid_sea, "to": eid_sa, "type": "调料-份量"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ============ 数据集生成 ============

TEMPLATES = [
    template_simple_ingredients,
    template_seasonings,
    template_cooking_step,
    template_marinade,
    template_multi_step,
    template_stir_fry_full,
    template_boiled_stew,
    template_list_with_prep,
    template_seasoning_mix,
    template_steam_bake,
]

TEMPLATE_WEIGHTS = [10, 8, 12, 8, 10, 10, 6, 8, 8, 6]  # 控制各模板采样频率

def generate_dataset(n_samples=1200):
    """生成训练数据集"""
    dataset = []
    attempts = 0
    max_attempts = n_samples * 3
    
    while len(dataset) < n_samples and attempts < max_attempts:
        attempts += 1
        template_func = random.choices(TEMPLATES, weights=TEMPLATE_WEIGHTS, k=1)[0]
        
        try:
            text, entities, relations = template_func()
        except Exception as e:
            continue
        
        # 去重实体ID
        entity_map = {}
        new_entities = []
        new_id = 0
        for e in entities:
            old_id = e["id"]
            if old_id not in entity_map:
                entity_map[old_id] = new_id
                new_id += 1
            new_entities.append({
                "id": entity_map[old_id],
                "start": e["start"],
                "end": e["end"],
                "label": e["label"]
            })
        
        # 重映射关系
        new_relations = []
        for r in relations:
            if r["from"] in entity_map and r["to"] in entity_map:
                new_relations.append({
                    "from": entity_map[r["from"]],
                    "to": entity_map[r["to"]],
                    "type": r["type"]
                })
        
        # 验证：所有实体引用都在实体列表中
        entity_ids = set(e["id"] for e in new_entities)
        valid = all(r["from"] in entity_ids and r["to"] in entity_ids for r in new_relations)
        
        if not valid:
            continue
        
        # 验证：实体不重叠
        spans = [(e["start"], e["end"]) for e in new_entities]
        spans_sorted = sorted(spans)
        overlap = False
        for j in range(len(spans_sorted) - 1):
            if spans_sorted[j][1] > spans_sorted[j+1][0]:
                overlap = True
                break
        
        if overlap:
            continue
        
        # 验证：实体在文本范围内
        text_len = len(text)
        for e in new_entities:
            if e["start"] < 0 or e["end"] > text_len:
                valid = False
                break
        
        if not valid:
            continue
        
        record = {
            "id": len(dataset),
            "text": text,
            "entities": new_entities,
            "relations": new_relations
        }
        dataset.append(record)
    
    return dataset


def generate_full_dataset():
    """生成完整的训练/验证/测试集"""
    print("正在生成训练数据...")
    
    all_data = generate_dataset(1200)
    
    # 去重（基于text）
    seen_texts = set()
    unique_data = []
    for item in all_data:
        if item["text"] not in seen_texts:
            seen_texts.add(item["text"])
            unique_data.append(item)
    
    # 重新编号
    for i, item in enumerate(unique_data):
        item["id"] = i
    
    print(f"去重后共 {len(unique_data)} 条数据")
    
    # 切分
    random.shuffle(unique_data)
    n = len(unique_data)
    train_end = int(n * 0.8)
    dev_end = int(n * 0.9)
    
    train = unique_data[:train_end]
    dev = unique_data[train_end:dev_end]
    test = unique_data[dev_end:]
    
    print(f"训练集: {len(train)} 条")
    print(f"验证集: {len(dev)} 条")
    print(f"测试集: {len(test)} 条")
    
    # 保存
    base_dir = "/data/workspace/recipe_re_dataset"
    
    def save_json(data, filename):
        with open(os.path.join(base_dir, filename), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    save_json(train, "train.json")
    save_json(dev, "dev.json")
    save_json(test, "test.json")
    save_json(unique_data, "all.json")
    
    # 统计
    stats = {"total": len(unique_data), "train": len(train), "dev": len(dev), "test": len(test)}
    
    entity_types = {}
    relation_types = {}
    total_entities = 0
    total_relations = 0
    
    for item in unique_data:
        for e in item["entities"]:
            entity_types[e["label"]] = entity_types.get(e["label"], 0) + 1
            total_entities += 1
        for r in item["relations"]:
            relation_types[r["type"]] = relation_types.get(r["type"], 0) + 1
            total_relations += 1
    
    stats["entity_types"] = entity_types
    stats["relation_types"] = relation_types
    stats["total_entities"] = total_entities
    stats["total_relations"] = total_relations
    stats["avg_entities_per_sample"] = round(total_entities / len(unique_data), 2)
    stats["avg_relations_per_sample"] = round(total_relations / len(unique_data), 2)
    
    save_json(stats, "stats.json")
    
    print("\n===== 数据集统计 =====")
    print(f"总样本数: {stats['total']}")
    print(f"总实体数: {stats['total_entities']}")
    print(f"总关系数: {stats['total_relations']}")
    print(f"平均每样本实体数: {stats['avg_entities_per_sample']}")
    print(f"平均每样本关系数: {stats['avg_relations_per_sample']}")
    print("\n实体类型分布:")
    for k, v in sorted(entity_types.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")
    print("\n关系类型分布:")
    for k, v in sorted(relation_types.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")
    
    # 展示样例
    print("\n===== 数据样例 =====")
    for i in range(min(8, len(unique_data))):
        item = unique_data[i]
        print(f"\n--- 样例 {i+1} ---")
        print(f"文本: {item['text']}")
        ent_str = ", ".join(f"{e['label']}:{item['text'][e['start']:e['end']]}" for e in item["entities"])
        print(f"实体: {ent_str}")
        rel_str = ", ".join(f"{item['entities'][r['from']]['label']}--{r['type']}--{item['entities'][r['to']]['label']}" for r in item["relations"])
        print(f"关系: {rel_str}")
    
    return train, dev, test, stats


if __name__ == "__main__":
    generate_full_dataset()
