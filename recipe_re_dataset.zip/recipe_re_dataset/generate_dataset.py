"""
菜谱关系抽取训练数据生成脚本
采用模板 + 多样化策略生成高质量标注数据
输出格式: JSON（Span-based RE 标准格式）
"""

import json
import random
import os

random.seed(42)

# ============ 词汇资源库 ============

INGREDIENTS = {
    "蔬菜": ["土豆", "西红柿", "青椒", "红椒", "洋葱", "大蒜", "生姜", "芹菜", "胡萝卜", "黄瓜", "茄子", "豆角", "白菜", "生菜", "菠菜", "韭菜", "香菜", "西兰花", "花菜", "莲藕", "山药", "芋头", "南瓜", "冬瓜", "丝瓜", "苦瓜", "秋葵", "芦笋", "竹笋", "木耳", "香菇", "金针菇", "平菇", "豆腐", "腐竹", "粉条"],
    "肉类": ["猪肉", "牛肉", "羊肉", "鸡胸肉", "鸡腿", "鸡翅", "鸭肉", "排骨", "五花肉", "里脊肉", "牛腩", "羊排", "鸡爪", "猪蹄", "肥肠", "猪肝", "猪肚", "牛筋", "肉馅", "火腿", "培根", "香肠"],
    "水产": ["鲫鱼", "鲈鱼", "草鱼", "带鱼", "三文鱼", "虾仁", "大虾", "蛤蜊", "扇贝", "鱿鱼", "章鱼", "螃蟹", "小龙虾", "海带", "紫菜"],
    "蛋奶": ["鸡蛋", "鸭蛋", "鹌鹑蛋", "牛奶", "酸奶", "奶酪", "黄油"],
    "主食": ["米饭", "面条", "馒头", "面包", "饺子皮", "馄饨皮", "年糕", "米粉", "粉丝", "意面", "通心粉"],
    "调料类": ["盐", "白糖", "冰糖", "生抽", "老抽", "蚝油", "料酒", "陈醋", "白醋", "番茄酱", "豆瓣酱", "辣椒酱", "花椒", "八角", "桂皮", "香叶", "孜然", "胡椒粉", "淀粉", "食用油", "芝麻油", "辣椒粉", "孜然粉", "五香粉", "鸡精", "味精", "蜂蜜", "老干妈"],
}

SEASONINGS = list(INGREDIENTS["调料类"])

# 合并所有食材
ALL_INGREDIENTS = []
for cat, items in INGREDIENTS.items():
    if cat != "调料类":
        ALL_INGREDIENTS.extend(items)

UNITS = {
    "重量": ["克", "千克", "斤", "两"],
    "体积": ["毫升", "升", "勺", "汤匙", "茶匙"],
    "计数": ["个", "只", "瓣", "根", "条", "片", "块", "朵", "颗", "粒", "把"],
    "其他": ["适量", "少许", "少量", "多量", "一撮"],
}

PREPARATIONS = {
    "切": ["切丝", "切片", "切块", "切丁", "切碎", "切末", "剁碎"],
    "处理": ["去皮", "去籽", "去蒂", "洗净", "沥干", "擦干", "掰开", "撕开", "拍碎", "压扁"],
    "腌/泡": ["腌制", "浸泡", "焯水", "过油", "炸至金黄", "煎至两面金黄"],
    "混合": ["搅拌均匀", "打散", "混合", "揉成面团", "捏成丸子"],
}

ACTIONS = {
    "炒": ["翻炒", "煸炒", "爆香", "干煸"],
    "煮": ["煮", "炖", "煲", "熬", "焯水"],
    "蒸": ["蒸", "隔水蒸"],
    "炸": ["炸", "煎", "烤", "烘"],
    "拌": ["拌匀", "搅拌", "抓匀", "腌制"],
    "其他": ["放入", "加入", "倒入", "撒入", "淋入", "裹上", "码入", "摆盘"],
}

COOKING_TIMES = ["1分钟", "2分钟", "3分钟", "5分钟", "8分钟", "10分钟", "15分钟", "20分钟", "25分钟", "30分钟", "40分钟", "1小时", "1.5小时", "2小时", "半小时", "十几分钟", "几分钟"]

# ============ 模板系统 ============

# 每个模板是一个函数，返回 (text, entities, relations)
# entity: {id, start, end, label}
# relation: {from, to, type}

entity_id_counter = 0
recipe_id_counter = 0

def get_id():
    global entity_id_counter
    entity_id_counter += 1
    return entity_id_counter

def reset_id():
    global entity_id_counter
    entity_id_counter = 0

def pick(items):
    return random.choice(items)

def pick_n(items, n):
    return random.sample(items, min(n, len(items)))

def generate_amount(unit_type=None):
    """生成份量描述"""
    if random.random() < 0.15:
        return pick(UNITS["其他"]), ""
    
    if unit_type == "重量" or (unit_type is None and random.random() < 0.4):
        unit = pick(UNITS["重量"])
        if unit in ["适量", "少许"]:
            return unit, ""
        num = random.choice([100, 150, 200, 250, 300, 350, 400, 500, 600, 750, 1000, 1.5, 2, 2.5, 3])
        return f"{num}{unit}", unit
    elif unit_type == "体积" or (unit_type is None and random.random() < 0.25):
        unit = pick(UNITS["体积"])
        num = random.choice([1, 2, 3, 5, 10, 15, 20, 30])
        return f"{num}{unit}", unit
    else:
        unit = pick(UNITS["计数"])
        if unit in ["适量", "少许"]:
            return unit, ""
        num = random.choice([1, 2, 3, 4, 5, 6, 8, 10, 12])
        return f"{num}{unit}", unit


# ---- 模板 1: 食材+份量+处理方式（最简单） ----
def template_1():
    """例: 土豆300克切丝，青椒1个切块"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 选2-4个食材
    n = random.randint(2, 4)
    selected = pick_n(ALL_INGREDIENTS, n)
    
    for ing in selected:
        eid = get_id()
        amount_text, unit = generate_amount()
        
        prep = pick(pick_n(list(PREPARATIONS.values()), 2))
        
        segment = f"{ing}{amount_text}{prep}"
        start = sum(len(p) for p in parts)
        parts.append(segment)
        
        # 食材实体
        entities.append({"id": eid, "start": start, "end": start + len(ing), "label": "食材"})
        ing_eid = eid
        
        # 份量实体
        eid2 = get_id()
        amt_start = start + len(ing)
        amt_end = amt_start + len(amount_text)
        entities.append({"id": eid2, "start": amt_start, "end": amt_end, "label": "份量"})
        relations.append({"from": ing_eid, "to": eid2, "type": "食材-份量"})
        
        # 处理方式实体
        eid3 = get_id()
        prep_start = amt_end
        prep_end = prep_start + len(prep)
        entities.append({"id": eid3, "start": prep_start, "end": prep_end, "label": "处理方式"})
        relations.append({"from": ing_eid, "to": eid3, "type": "食材-处理方式"})
    
    text = "，".join(parts) + "。"
    return text, entities, relations


# ---- 模板 2: 调料+份量 ----
def template_2():
    """例: 加入生抽1勺、盐适量、白糖半勺调味"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    n = random.randint(2, 4)
    selected = pick_n(SEASONINGS, n)
    
    for i, sea in enumerate(selected):
        eid = get_id()
        amount_text, unit = generate_amount()
        
        if i == 0:
            segment = f"加入{sea}{amount_text}"
        elif i == len(selected) - 1:
            segment = f"和{sea}{amount_text}调味"
        else:
            segment = f"{sea}{amount_text}"
        
        start = sum(len(p) for p in parts)
        parts.append(segment)
        
        # 调料实体
        sea_start = start + (0 if i == 0 else 0)  # 简化：直接从start算
        # 重新精确计算
        if i == 0:
            sea_start = start + 2  # "加入"
            sea_end = sea_start + len(sea)
        elif i == len(selected) - 1:
            sea_start = start + 0
            sea_end = sea_start + len(sea)
        else:
            sea_start = start
            sea_end = sea_start + len(sea)
        
        entities.append({"id": eid, "start": sea_start, "end": sea_end, "label": "调料"})
        sea_eid = eid
        
        # 份量
        eid2 = get_id()
        amt_start = sea_end
        amt_end = amt_start + len(amount_text)
        entities.append({"id": eid2, "start": amt_start, "end": amt_end, "label": "份量"})
        relations.append({"from": sea_eid, "to": eid2, "type": "调料-份量"})
    
    text = "，".join(parts) + "。"
    return text, entities, relations


# ---- 模板 3: 完整步骤（食材+动作+时间） ----
def template_3():
    """例: 热锅下油，放入土豆丝翻炒5分钟，加入盐调味"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 前半句：动作+食材
    action_verb = pick(ACTIONS["炒"] + ACTIONS["煮"] + ACTIONS["炸"] + ["放入", "加入"])
    ing = pick(ALL_INGREDIENTS)
    prep = pick(pick_n(list(PREPARATIONS.values()), 2))
    
    # 可能有份量
    amount_text, unit = generate_amount()
    
    segment1 = f"热锅下油，"
    start1 = 0
    parts.append(segment1)
    
    # 动作
    eid_act = get_id()
    act_start = len(segment1)
    act_end = act_start + len(action_verb)
    entities.append({"id": eid_act, "start": act_start, "end": act_end, "label": "动作"})
    
    segment2 = f"{action_verb}{ing}{prep}"
    parts.append(segment2)
    
    # 食材
    eid_ing = get_id()
    ing_start = act_end
    ing_end = ing_start + len(ing)
    entities.append({"id": eid_ing, "start": ing_start, "end": ing_end, "label": "食材"})
    relations.append({"from": eid_act, "to": eid_ing, "type": "动作-对象"})
    
    # 处理方式
    eid_prep = get_id()
    prep_start = ing_end
    prep_end = prep_start + len(prep)
    entities.append({"id": eid_prep, "start": prep_start, "end": prep_end, "label": "处理方式"})
    relations.append({"from": eid_ing, "to": eid_prep, "type": "食材-处理方式"})
    
    # 时间
    cook_time = pick(COOKING_TIMES)
    eid_time = get_id()
    time_start = prep_end
    time_end = time_start + len(cook_time)
    entities.append({"id": eid_time, "start": time_start, "end": time_end, "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    segment3 = f"{cook_time}"
    parts.append(segment3)
    
    # 后半句：加调料
    sea = pick(SEASONINGS)
    eid_sea = get_id()
    sea_amount, _ = generate_amount()
    
    segment4 = f"，加入{sea}{sea_amount}调味"
    parts.append(segment4)
    sea_start = sum(len(p) for p in parts[:-1]) + 2  # "加入"
    sea_end = sea_start + len(sea)
    entities.append({"id": eid_sea, "start": sea_start, "end": sea_end, "label": "调料"})
    
    eid_sa = get_id()
    sa_start = sea_end
    sa_end = sa_start + len(sea_amount)
    entities.append({"id": eid_sa, "start": sa_start, "end": sa_end, "label": "份量"})
    relations.append({"from": eid_sea, "to": eid_sa, "type": "调料-份量"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ---- 模板 4: 腌制/预处理步骤 ----
def template_4():
    """例: 将鸡腿500克用生抽2勺、料酒1勺腌制20分钟"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    ing = pick(ALL_INGREDIENTS)
    amount_text, unit = generate_amount("重量")
    
    segment1 = f"将{ing}{amount_text}"
    start1 = 0
    parts.append(segment1)
    
    eid_ing = get_id()
    ing_start = 1  # "将"
    ing_end = ing_start + len(ing)
    entities.append({"id": eid_ing, "start": ing_start, "end": ing_end, "label": "食材"})
    
    eid_amt = get_id()
    amt_start = ing_end
    amt_end = amt_start + len(amount_text)
    entities.append({"id": eid_amt, "start": amt_start, "end": amt_end, "label": "份量"})
    relations.append({"from": eid_ing, "to": eid_amt, "type": "食材-份量"})
    
    # 用调料腌制
    n_sea = random.randint(1, 3)
    selected_sea = pick_n(SEASONINGS, n_sea)
    
    sea_descs = []
    sea_amounts = []
    for sea in selected_sea:
        sa, _ = generate_amount("体积")
        sea_descs.append(f"{sea}{sa}")
        sea_amounts.append(sa)
    
    sea_text = "、".join(sea_descs)
    
    cook_time = pick(COOKING_TIMES)
    
    segment2 = f"用{sea_text}腌制{cook_time}"
    parts.append(segment2)
    
    # 动作
    eid_act = get_id()
    act_start = sum(len(p) for p in [segment1])
    act_text = "腌制"
    act_end = act_start + len(act_text)
    # 找到"腌制"的位置
    腌制_pos = segment2.index("腌制")
    act_start = len(segment1) + 腌制_pos
    act_end = act_start + 2
    entities.append({"id": eid_act, "start": act_start, "end": act_end, "label": "动作"})
    relations.append({"from": eid_act, "to": eid_ing, "type": "动作-对象"})
    
    # 时间
    eid_time = get_id()
    time_start = act_end
    time_end = time_start + len(cook_time)
    entities.append({"id": eid_time, "start": time_start, "end": time_end, "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    
    # 调料
    for i, (sea, sa) in enumerate(zip(selected_sea, sea_amounts)):
        # 找到调料在文本中的位置
        sea_pos = segment2.index(sea)
        sea_abs_start = len(segment1) + sea_pos
        sea_abs_end = sea_abs_start + len(sea)
        
        eid_s = get_id()
        entities.append({"id": eid_s, "start": sea_abs_start, "end": sea_abs_end, "label": "调料"})
        
        # 在调料后面找份量
        sa_search_start = sea_pos + len(sea)
        sa_pos = segment2.find(sa, sea_pos)
        if sa_pos == -1:
            # 如果精确匹配失败，尝试在segment2中搜索
            sa_pos = segment2.index(sa)
        sa_abs_start = len(segment1) + sa_pos
        sa_abs_end = sa_abs_start + len(sa)
        
        eid_sa = get_id()
        entities.append({"id": eid_sa, "start": sa_abs_start, "end": sa_abs_end, "label": "份量"})
        relations.append({"from": eid_s, "to": eid_sa, "type": "调料-份量"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ---- 模板 5: 多步骤连贯 ----
def template_5():
    """例: 土豆300克去皮切丝，青椒1个去籽切块，热锅爆香蒜末，下入土豆丝翻炒3分钟"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 食材1
    ing1 = pick(ALL_INGREDIENTS)
    amt1, _ = generate_amount()
    prep1 = pick(PREPARATIONS["处理"] + PREPARATIONS["切"])
    
    seg1 = f"{ing1}{amt1}{prep1}，"
    parts.append(seg1)
    
    eid1 = get_id()
    entities.append({"id": eid1, "start": 0, "end": len(ing1), "label": "食材"})
    
    eid1a = get_id()
    entities.append({"id": eid1a, "start": len(ing1), "end": len(ing1) + len(amt1), "label": "份量"})
    relations.append({"from": eid1, "to": eid1a, "type": "食材-份量"})
    
    eid1p = get_id()
    entities.append({"id": eid1p, "start": len(ing1) + len(amt1), "end": len(ing1) + len(amt1) + len(prep1), "label": "处理方式"})
    relations.append({"from": eid1, "to": eid1p, "type": "食材-处理方式"})
    
    # 食材2
    ing2 = pick(ALL_INGREDIENTS)
    while ing2 == ing1:
        ing2 = pick(ALL_INGREDIENTS)
    amt2, _ = generate_amount()
    prep2 = pick(PREPARATIONS["处理"] + PREPARATIONS["切"])
    
    seg2 = f"{ing2}{amt2}{prep2}，"
    parts.append(seg2)
    
    offset2 = len(seg1)
    eid2 = get_id()
    entities.append({"id": eid2, "start": offset2, "end": offset2 + len(ing2), "label": "食材"})
    
    eid2a = get_id()
    entities.append({"id": eid2a, "start": offset2 + len(ing2), "end": offset2 + len(ing2) + len(amt2), "label": "份量"})
    relations.append({"from": eid2, "to": eid2a, "type": "食材-份量"})
    
    eid2p = get_id()
    entities.append({"id": eid2p, "start": offset2 + len(ing2) + len(amt2), "end": offset2 + len(ing2) + len(amt2) + len(prep2), "label": "处理方式"})
    relations.append({"from": eid2, "to": eid2p, "type": "食材-处理方式"})
    
    # 动作句
    action = pick(ACTIONS["炒"] + ["爆香", "下入", "放入"])
    ing_for_action = pick([ing1, ing2])
    cook_time = pick(COOKING_TIMES)
    
    seg3 = f"热锅{action}{ing_for_action}{cook_time}"
    parts.append(seg3)
    
    offset3 = len(seg1) + len(seg2)
    eid_act = get_id()
    act_start_in_seg = seg3.index(action)
    entities.append({"id": eid_act, "start": offset3 + act_start_in_seg, "end": offset3 + act_start_in_seg + len(action), "label": "动作"})
    
    # 时间
    eid_time = get_id()
    time_start_in_seg = seg3.index(cook_time)
    entities.append({"id": eid_time, "start": offset3 + time_start_in_seg, "end": offset3 + time_start_in_seg + len(cook_time), "label": "时间"})
    relations.append({"from": eid_act, "to": eid_time, "type": "动作-时间"})
    
    # 找到被动作作用的食材
    target_eid = eid1 if ing_for_action == ing1 else eid2
    relations.append({"from": eid_act, "to": target_eid, "type": "动作-对象"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ---- 模板 6: 简单食材列举 ----
def template_6():
    """例: 准备食材：土豆200克，牛肉300克，洋葱1个"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    n = random.randint(3, 5)
    selected = pick_n(ALL_INGREDIENTS, n)
    
    seg0 = "准备食材："
    parts.append(seg0)
    
    for i, ing in enumerate(selected):
        amt, _ = generate_amount()
        if i < n - 1:
            seg = f"{ing}{amt}，"
        else:
            seg = f"{ing}{amt}"
        parts.append(seg)
        
        offset = sum(len(p) for p in parts[:-1])
        eid = get_id()
        entities.append({"id": eid, "start": offset, "end": offset + len(ing), "label": "食材"})
        
        eid_a = get_id()
        entities.append({"id": eid_a, "start": offset + len(ing), "end": offset + len(ing) + len(amt), "label": "份量"})
        relations.append({"from": eid, "to": eid_a, "type": "食材-份量"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ---- 模板 7: 调料段 ----
def template_7():
    """例: 调料：生抽2勺，老抽1勺，白糖1勺，盐适量"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    n = random.randint(3, 5)
    selected = pick_n(SEASONINGS, n)
    
    seg0 = "调料："
    parts.append(seg0)
    
    for i, sea in enumerate(selected):
        amt, _ = generate_amount()
        if i < n - 1:
            seg = f"{sea}{amt}，"
        else:
            seg = f"{sea}{amt}"
        parts.append(seg)
        
        offset = sum(len(p) for p in parts[:-1])
        eid = get_id()
        entities.append({"id": eid, "start": offset, "end": offset + len(sea), "label": "调料"})
        
        eid_a = get_id()
        entities.append({"id": eid_a, "start": offset + len(sea), "end": offset + len(sea) + len(amt), "label": "份量"})
        relations.append({"from": eid, "to": eid_a, "type": "调料-份量"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ---- 模板 8: 烹饪动作+调料+食材综合 ----
def template_8():
    """例: 锅中倒入食用油烧热，下入葱姜蒜爆香，加入牛肉翻炒至变色"""
    reset_id()
    parts = []
    entities = []
    relations = []
    
    # 前半：热油
    seg1 = "锅中倒入食用油烧热，"
    parts.append(seg1)
    
    # 爆香
    aromatics = pick_n(["葱", "姜", "蒜", "洋葱"], random.randint(2, 3))
    aromatics_text = "、".join(aromatics)
    
    seg2 = f"下入{aromatics_text}爆香，"
    parts.append(seg2)
    
    # 爆香动作
    offset2 = len(seg1)
    eid_act = get_id()
    爆香_pos = seg2.index("爆香")
    entities.append({"id": eid_act, "start": offset2 + 爆香_pos, "end": offset2 + 爆香_pos + 2, "label": "动作"})
    
    # 香辛料实体
    for a in aromatics:
        a_pos = seg2.index(a)
        eid_a = get_id()
        entities.append({"id": eid_a, "start": offset2 + a_pos, "end": offset2 + a_pos + len(a), "label": "食材"})
        relations.append({"from": eid_act, "to": eid_a, "type": "动作-对象"})
    
    # 后半：主料
    main_ing = pick(ALL_INGREDIENTS)
    action2 = pick(ACTIONS["炒"])
    cook_time = pick(COOKING_TIMES)
    
    seg3 = f"加入{main_ing}{action2}{cook_time}"
    parts.append(seg3)
    
    offset3 = len(seg1) + len(seg2)
    
    # 动作2
    eid_act2 = get_id()
    act2_pos = seg3.index(action2)
    entities.append({"id": eid_act2, "start": offset3 + act2_pos, "end": offset3 + act2_pos + len(action2), "label": "动作"})
    
    # 主料
    eid_main = get_id()
    main_pos = seg3.index(main_ing)
    entities.append({"id": eid_main, "start": offset3 + main_pos, "end": offset3 + main_pos + len(main_ing), "label": "食材"})
    relations.append({"from": eid_act2, "to": eid_main, "type": "动作-对象"})
    
    # 时间
    eid_time = get_id()
    time_pos = seg3.index(cook_time)
    entities.append({"id": eid_time, "start": offset3 + time_pos, "end": offset3 + time_pos + len(cook_time), "label": "时间"})
    relations.append({"from": eid_act2, "to": eid_time, "type": "动作-时间"})
    
    text = "".join(parts) + "。"
    return text, entities, relations


# ============ 生成数据集 ============

TEMPLATES = [template_1, template_2, template_3, template_4, template_5, template_6, template_7, template_8]

def generate_dataset(n_samples=1000):
    """生成训练数据集"""
    dataset = []
    
    for i in range(n_samples):
        template_func = pick(TEMPLATES)
        text, entities, relations = template_func()
        
        # 去重实体ID（确保连续）
        # 重新编号实体
        entity_map = {}
        new_entities = []
        new_id = 0
        for e in entities:
            old_id = e["id"]
            if old_id not in entity_map:
                entity_map[old_id] = new_id
                new_id += 1
            new_entities.append({
                "id": entity_map[old_id],
                "start": e["start"],
                "end": e["end"],
                "label": e["label"]
            })
        
        # 重映射关系
        new_relations = []
        for r in relations:
            new_relations.append({
                "from": entity_map.get(r["from"], r["from"]),
                "to": entity_map.get(r["to"], r["to"]),
                "type": r["type"]
            })
        
        # 验证：所有实体引用都在实体列表中
        valid = True
        entity_ids = set(e["id"] for e in new_entities)
        for r in new_relations:
            if r["from"] not in entity_ids or r["to"] not in entity_ids:
                valid = False
                break
        
        if not valid:
            continue
        
        # 验证：实体不重叠（可选检查）
        spans = [(e["start"], e["end"]) for e in new_entities]
        spans_sorted = sorted(spans)
        for j in range(len(spans_sorted) - 1):
            if spans_sorted[j][1] > spans_sorted[j+1][0]:
                # 有重叠，跳过
                valid = False
                break
        
        if not valid:
            continue
        
        record = {
            "id": i,
            "text": text,
            "entities": new_entities,
            "relations": new_relations
        }
        dataset.append(record)
    
    return dataset


def generate_full_dataset():
    """生成完整的训练/验证/测试集"""
    print("正在生成训练数据...")
    
    all_data = generate_dataset(1500)
    
    # 去重（基于text）
    seen_texts = set()
    unique_data = []
    for item in all_data:
        if item["text"] not in seen_texts:
            seen_texts.add(item["text"])
            unique_data.append(item)
    
    print(f"去重后共 {len(unique_data)} 条数据")
    
    # 切分
    random.shuffle(unique_data)
    n = len(unique_data)
    train_end = int(n * 0.8)
    dev_end = int(n * 0.9)
    
    train = unique_data[:train_end]
    dev = unique_data[train_end:dev_end]
    test = unique_data[dev_end:]
    
    print(f"训练集: {len(train)} 条")
    print(f"验证集: {len(dev)} 条")
    print(f"测试集: {len(test)} 条")
    
    # 保存
    base_dir = "/data/workspace/recipe_re_dataset"
    
    with open(os.path.join(base_dir, "train.json"), "w", encoding="utf-8") as f:
        json.dump(train, f, ensure_ascii=False, indent=2)
    
    with open(os.path.join(base_dir, "dev.json"), "w", encoding="utf-8") as f:
        json.dump(dev, f, ensure_ascii=False, indent=2)
    
    with open(os.path.join(base_dir, "test.json"), "w", encoding="utf-8") as f:
        json.dump(test, f, ensure_ascii=False, indent=2)
    
    # 合并全部
    with open(os.path.join(base_dir, "all.json"), "w", encoding="utf-8") as f:
        json.dump(unique_data, f, ensure_ascii=False, indent=2)
    
    # 统计信息
    stats = {
        "total": len(unique_data),
        "train": len(train),
        "dev": len(dev),
        "test": len(test),
    }
    
    # 统计实体和关系类型分布
    entity_types = {}
    relation_types = {}
    total_entities = 0
    total_relations = 0
    
    for item in unique_data:
        for e in item["entities"]:
            entity_types[e["label"]] = entity_types.get(e["label"], 0) + 1
            total_entities += 1
        for r in item["relations"]:
            relation_types[r["type"]] = relation_types.get(r["type"], 0) + 1
            total_relations += 1
    
    stats["entity_types"] = entity_types
    stats["relation_types"] = relation_types
    stats["total_entities"] = total_entities
    stats["total_relations"] = total_relations
    stats["avg_entities_per_sample"] = round(total_entities / len(unique_data), 2)
    stats["avg_relations_per_sample"] = round(total_relations / len(unique_data), 2)
    
    with open(os.path.join(base_dir, "stats.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)
    
    print("\n===== 数据集统计 =====")
    print(f"总样本数: {stats['total']}")
    print(f"总实体数: {stats['total_entities']}")
    print(f"总关系数: {stats['total_relations']}")
    print(f"平均每样本实体数: {stats['avg_entities_per_sample']}")
    print(f"平均每样本关系数: {stats['avg_relations_per_sample']}")
    print("\n实体类型分布:")
    for k, v in sorted(entity_types.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")
    print("\n关系类型分布:")
    for k, v in sorted(relation_types.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")
    
    # 展示几个样例
    print("\n===== 数据样例 =====")
    for i in range(min(5, len(unique_data))):
        item = unique_data[i]
        print(f"\n--- 样例 {i+1} ---")
        print(f"文本: {item['text']}")
        print(f"实体: {json.dumps(item['entities'], ensure_ascii=False)}")
        print(f"关系: {json.dumps(item['relations'], ensure_ascii=False)}")
    
    return train, dev, test, stats


if __name__ == "__main__":
    generate_full_dataset()
